export class Note {
  title: String = '';
  note: String = '';
  constructor(title: String, note: String) {
    title = '';
    note = '';
  }
}
